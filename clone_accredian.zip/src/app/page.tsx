import Image from "next/image";
import Hero from "./Hero";
import Navbar from "./Navbar";
import LeadForm from "./Leadform";
import HowItWorks from "./Howitworks";
import Programs from "./Programs";
import StatsBar from "./Statsbar";
import Testimonials from "./Testimonials";
import WhyAccredian from "./Whyaccredian";
import Footer from "./Footer";

export default function Home() {
  return (
    <div className="flex flex-col flex-1 items-center justify-center bg-zinc-50 font-sans dark:bg-black">
      <Navbar/>
      <Hero/>
      <LeadForm/>
      <HowItWorks/>
      <Programs/>
      <Testimonials/>
      <WhyAccredian/>
      <Footer/>
    </div>
  );
}
